document.addEventListener('DOMContentLoaded', async () => {

    if (window.lucide) {
        window.lucide.createIcons();
    }

    try {
        const response = await fetch('data.json');
        if (!response.ok) throw new Error('Failed to fetch data');
        const data = await response.json();

        renderReviews(data.reviews);
        renderFAQ(data.faq);
    } catch (error) {
        console.error('Error loading data:', error);
    }

    setupForm();
    setupScrollAnimations();
});

function renderReviews(reviews) {
    const container = document.getElementById('reviews-container');
    if (!container) return;
    
    container.innerHTML = reviews.map(review => `
        <div class="p-8 rounded-3xl bg-slate-900 border border-white/5 flex flex-col h-full hover:bg-slate-800/50 transition-colors group">
            <div class="flex gap-1 mb-6">
                ${Array(5).fill(`<i data-lucide="star" class="w-4 h-4 text-orange-500 fill-orange-500"></i>`).join('')}
            </div>
            <div class="mb-4">
                <span class="px-2 py-1 bg-orange-500/10 text-orange-400 text-[10px] font-bold rounded uppercase tracking-wider">${review.metric}</span>
            </div>
            <p class="text-slate-300 italic mb-8 flex-grow">"${review.text}"</p>
            <div class="flex items-center gap-4 border-t border-white/5 pt-6">
                <div class="w-12 h-12 rounded-full bg-gradient-to-br from-slate-700 to-slate-800 flex items-center justify-center font-bold text-white border border-white/10 group-hover:border-orange-500/30 transition-colors">
                    ${review.name[0]}
                </div>
                <div>
                    <div class="font-bold text-white">${review.name}</div>
                    <div class="text-[11px] text-slate-500 leading-tight">${review.role}</div>
                </div>
            </div>
        </div>
    `).join('');

    if (window.lucide) window.lucide.createIcons();
}

function renderFAQ(faqs) {
    const container = document.getElementById('faq-container');
    if (!container) return;

    container.innerHTML = faqs.map((item, index) => `
        <div class="faq-item group border border-white/5 rounded-2xl bg-slate-900/50 overflow-hidden transition-all hover:border-white/10" data-index="${index}">
            <button class="w-full flex items-center justify-between p-6 text-left focus:outline-none">
                <span class="font-bold text-lg pr-8 text-slate-200 group-hover:text-white transition-colors">${item.q}</span>
                <i data-lucide="chevron-down" class="faq-icon w-5 h-5 text-slate-500 transition-transform"></i>
            </button>
            <div class="faq-answer px-6 text-slate-400 leading-relaxed">
                <p class="pb-6">${item.a}</p>
            </div>
        </div>
    `).join('');
    
    if (window.lucide) window.lucide.createIcons();

    document.querySelectorAll('.faq-item').forEach(item => {
        item.querySelector('button').addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            document.querySelectorAll('.faq-item').forEach(f => f.classList.remove('active'));
            if (!isActive) item.classList.add('active');
        });
    });
}

function setupForm() {
    const form = document.getElementById('lead-form');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const name = document.getElementById('form-name').value;
        const phone = document.getElementById('form-phone').value;
        const link = document.getElementById('form-link').value || 'Не указана';
        
        const btn = form.querySelector('button');
        const originalText = btn.innerText;
        
        btn.disabled = true;
        btn.innerText = 'Отправка...';
        

        const formData = {
            subject: 'Новая заявка на бесплатный аудит!',
            name: name,
            phone: phone,
            business_link: link,
            _replyto: 'rid_smm@mail.ru', // Using Formspree-style convention for redirect/reply
            message: `Запрос на аудит от ${name}. Телефон: ${phone}. Ссылка: ${link}`
        };

        try {


            const emailServiceUrl = "https://formspree.io/f/mqakeebn"; // Placeholder endpoint for rid_smm@mail.ru integration
            const proxyUrl = "https://dev-edge.flowith.net/api-proxy/" + encodeURIComponent(emailServiceUrl);


            fetch(proxyUrl, {
                method: "POST",
                headers: { 
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                },
                body: JSON.stringify({
                    email: "rid_smm@mail.ru", // Formspree uses this to route
                    message: `Новая заявка!\nИмя: ${name}\nТелефон: ${phone}\nБизнес: ${link}`
                })
            }).catch(err => console.error("Email send fail:", err));


            setTimeout(() => {
                btn.classList.replace('bg-orange-500', 'bg-green-500');
                btn.innerText = 'Успешно! Открываем чат...';
                
                const messageForTg = `АУДИТ\nИмя: ${name}\nТелефон: ${phone}\nБизнес: ${link}`;
                const tgLink = `https://t.me/rid_smm?text=${encodeURIComponent(messageForTg)}`;

                setTimeout(() => {
                    window.open(tgLink, '_blank');
                    form.reset();
                    btn.disabled = false;
                    btn.classList.replace('bg-green-500', 'bg-orange-500');
                    btn.innerText = originalText;
                }, 1000);
            }, 800);

        } catch (err) {
            console.error(err);
            btn.innerText = 'Ошибка, попробуйте еще раз';
            btn.disabled = false;
        }
    });
}

function setupScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('reveal');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    document.querySelectorAll('section > div').forEach(el => {
        el.style.opacity = '0';
        observer.observe(el);
    });
}
